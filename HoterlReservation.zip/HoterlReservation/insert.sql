﻿insert into Rooms values(0,25)
insert into Rooms values(0,25)
insert into Rooms values(0,25)
insert into Rooms values(0,25)
insert into Rooms values(0,25)
insert into Rooms values(0,50)
insert into Rooms values(0,50)
insert into Rooms values(0,50)
insert into Rooms values(0,50)
insert into Rooms values(0,250)


Insert into Clients values('TestNam', 'TestSurName', 'your-email','730206519', 10)