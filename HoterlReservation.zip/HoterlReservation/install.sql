﻿CREATE TABLE Rooms (
Id int identity(1,1) primary key,
PriceByDay decimal(38,2),
IsOccupied int
)

CREATE TABLE Clients (
Id int identity(1,1) primary key,
ClientName varchar(100),
ClientSurname varchar(100),
Email varchar(100) not null,
PhoneNumber varchar(100),
AmountOfVisits int,
);

CREATE TABLE RoomReservations(
Id int identity(1,1) primary key,
ClientId int,
RoomId int,
PriceToPay decimal(38,2),
OccupiedFrom date,
OccupiedTo date

FOREIGN KEY (ClientId) REFERENCES Clients(Id) ON DELETE CASCADE,
FOREIGN KEY (RoomId) REFERENCES Rooms(Id) ON DELETE CASCADE,
);