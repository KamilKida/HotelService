﻿using HoterlReservation.SqlModels;

namespace HoterlReservation
{
    public static class Params
    {
        /// <summary>
        /// Email z którego będą wysyłane wiadomości.
        /// </summary>
        public static string Email { get; set; }

        /// <summary>
        /// Hasło emaila z którego będą wysyłane wiadomości.
        /// </summary>
        public static string Password { get; set; }

        /// <summary>
        /// Adres serwera bazy danych.
        /// </summary>
        public static string DbServer { get; set; }

        /// <summary>
        /// Nazwa bazy danych.
        /// </summary>
        public static string DbName { get; set; }

        /// <summary>
        /// Objekt reprezentujący nową rezerwacje.
        /// </summary>
        public static RoomReservations CreatedReservation { get; set;} = new RoomReservations();

    }
}
