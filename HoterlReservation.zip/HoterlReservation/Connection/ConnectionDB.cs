﻿using HoterlReservation.Mapping;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Mapping.ByCode;

namespace HoterlReservation.Connection
{

    public static class ConnectionDB
    {
        public static ISessionFactory NH;

        /// <summary>
        /// Metoda inicjująca połączenie z bazą danych.
        /// </summary>
        public static void Init()
        {
            List<Type> mappedClasses = new List<Type>() {
                typeof(ClientsMap),
                typeof(RoomReservationsMap),
                typeof(RoomsMap),
            };

            var config = new Configuration();

            config.DataBaseIntegration(db =>
            {
                db.ConnectionString = $"Server={Params.DbServer};Database={Params.DbName};Trusted_Connection=True";
                db.Dialect<NHibernate.Dialect.MsSql2012Dialect>();
            });

            var mapper = new ModelMapper();
            mapper.AddMappings(mappedClasses);

            var mapping = mapper.CompileMappingForAllExplicitlyAddedEntities();
            config.AddMapping(mapping);

            ConnectionDB.NH = config.BuildSessionFactory();
        }
    }
}
            


    