﻿using HoterlReservation.SqlModels;
using System;
using System.Net;
using System.Net.Mail;

namespace HoterlReservation.Methods
{
    public static class EmailMethod
    {
        /// <summary>
        /// Metoda do wysyłania wiadomości na wskazany adres e-mail.
        /// </summary>
        public static void SendMail()
        {
            try
            {
                MailMessage mail = new MailMessage();

                mail.From = new MailAddress(Params.Email);

                mail.To.Add(Params.CreatedReservation.Client.Email);

                mail.Subject = "Rezerwacja pokoju";

                string message = $"Panie/Pani {Params.CreatedReservation.Client.ClientName} {Params.CreatedReservation.Client.ClientSurname}. " +
                                 $"\nZ przyjemnością informuję, że pokuj, o numerze: {Params.CreatedReservation.RoomId}, został pomyślnie zarezerwowany." +
                                 $"\nOkres rezerwacji będzie trwał od: {Params.CreatedReservation.OccupiedFrom.ToString("dd-MM-yyyy")}, do: {Params.CreatedReservation.OccupiedTo.ToString("dd-MM-yyyy")}." +
                                 $"\nCena rezerwacji wynosi: {Params.CreatedReservation.PriceToPay.ToString("F2")} zł.";

                if(Params.CreatedReservation.Client.AmountOfVisits > 0)
                {
                    message += $"\nCena została obniżona z {Params.CreatedReservation.OrginalRoomPrice.ToString("F2")} zł dzięki rabatowi: {Params.CreatedReservation.Client.Discount} %.";
                }

                message += "\nDziękujemy za wybór naszego hotelu";

                mail.Body = message;

                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");

                smtpClient.Port = 587;
                smtpClient.Credentials = new NetworkCredential(Params.Email,Params.Password);
                smtpClient.EnableSsl = true;

                smtpClient.Send(mail);
 
            }
            catch
            {
                throw new Exception("Nie udalo sie wysłać maila.");
            }
        }
    }
}
