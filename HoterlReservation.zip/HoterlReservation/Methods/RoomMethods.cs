﻿using HoterlReservation.Connection;
using HoterlReservation.SqlModels;

namespace HoterlReservation.Methods
{
    public static class RoomMethods
    {
        /// <summary>
        /// Metoda pobierająca liste pokoi z bazy danych.
        /// </summary>
        /// <returns>Liste pokoi z bazy danych.</returns>
        public static List<Rooms> GetRooms()
        {
            try
            {
                var roomsList = new List<Rooms>();

                using (var sesion = ConnectionDB.NH.OpenSession())
                {
                    roomsList = sesion.Query<Rooms>().ToList();
                }

                roomsList.ForEach(x =>
                {
                    if (x.IsOccupied == 1)
                    {
                        x.IsOccupiedString = "TAK";
                    }
                    else
                    {
                        x.IsOccupiedString = "NIE";
                    }
                });

                return roomsList;
            }
            catch
            {
                return null;
            }
        }

    }
}
