﻿using HoterlReservation.Connection;
using HoterlReservation.SqlModels;

namespace HoterlReservation.Methods
{
    public static class ClientMethods
    {
        /// <summary>
        /// Pobiera istniejącego klienta po jego e-mailu.
        /// </summary>
        /// <param name="clientEmail">Email klienta.</param>
        /// <returns>Objekt Clients.</returns>
        public static Clients GetClient(string clientEmail)
        {
            try
            {
                using (var sesion = ConnectionDB.NH.OpenSession())
                {
                    return sesion.Query<Clients>().Where(x => x.Email == clientEmail).FirstOrDefault();
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Tworzy w bazie danych wpis z informacjami o nowym kliencie.
        /// </summary>
        /// <param name="newClient">Objek który ma reprezentować nowego klienta.</param>
        /// <returns>Id klienta.</returns>
        public static int CreateClient(Clients newClient)
        {
            try
            {
                var clientId = -1;

                using (var sesion = ConnectionDB.NH.OpenSession())
                {
                    using (var transaction = sesion.BeginTransaction())
                    {
                        clientId = (int)sesion.Save(newClient);
                        transaction.Commit();
                    }

                    return clientId;
                }
            }
            catch
            {
                return -1;
            }

        }

        
    }
}
