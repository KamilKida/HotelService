﻿using HoterlReservation.Connection;
using HoterlReservation.SqlModels;

namespace HoterlReservation.Methods
{
    public static class ReservationMethod
    {
        /// <summary>
        /// Metoda słurząca do tworzenia wpisów w bazie danych o nowej rezerwacji.
        /// </summary>
        /// <param name="reservation">Objekt RoomReservations reprezentujący nowy wpis.</param>
        public static void CreateReservation(RoomReservations reservation)
        {
            using (var sesion = ConnectionDB.NH.OpenSession())
            {
                using (var transiction = sesion.BeginTransaction())
                {
                    var reservationId = sesion.Save(reservation);

                    Params.CreatedReservation.Id = (int)reservationId;

                    var occupiedRoom = sesion.Query<Rooms>().Where(x => x.Id == reservation.RoomId).FirstOrDefault();

                    occupiedRoom.IsOccupied = 1;
                    sesion.Update(occupiedRoom);

                    transiction.Commit();

                    Params.CreatedReservation = reservation;

                }
            }

        }

        /// <summary>
        /// Metoda służąca do usuwania rezerwacji z bazy danych.
        /// </summary>
        /// <param name="roomId">Numer/Id pokoju na rezerwacji..</param>
        /// <param name="clientEmail">Email klienta na rezerwacji.</param>
        /// <returns></returns>
        public static bool DeleteReservation(int roomId, string clientEmail)
        {
            try
            {
                using (var sesion = ConnectionDB.NH.OpenSession())
                {
                    var clientId = sesion.Query<Clients>().Where(x => x.Email == clientEmail).Select(x => x.Id).FirstOrDefault();

                    var reservationToDelete = sesion.Query<RoomReservations>().Where(x => x.RoomId == roomId && clientId == clientId).FirstOrDefault();
                    var reservedRoom = sesion.Query<Rooms>().Where(x => x.Id == roomId).FirstOrDefault();
                    reservedRoom.IsOccupied = 0;

                    using (var transaction = sesion.BeginTransaction())
                    {
                        sesion.Update(reservedRoom);
                        sesion.Delete(reservationToDelete);
                        transaction.Commit();
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
