﻿using HoterlReservation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using HoterlReservation.Methods;
using HoterlReservation.SqlModels;

namespace HoterlReservation.Controllers
{
    public class ResultController : Controller
    {
        private readonly ILogger<ResultController> _logger;

        public ResultController(ILogger<ResultController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Akcja wyświetlająca informacje o zarezerwowaniu pokoju wraz z wysłaniem wiadomości e-mail.
        /// </summary>
        public IActionResult SuccessWithEmailView()
        {
            
            return View(Params.CreatedReservation);
        }

        /// <summary>
        /// Akcja wyświetlająca informacje o złych datach rezerwacji pokoju.
        /// </summary>
        public IActionResult WrongDateView()
        {
            return View(Params.CreatedReservation);
        }

        

        /// <summary>
        /// Akcja wyświetlająca informacje o wyborze złego pokoju.
        /// </summary>
        public IActionResult WrongRoomView()
        {
            return View(Params.CreatedReservation);
        }


        /// <summary>
        /// Akcja wyświetlająca stronę początkową aplikacji.
        /// </summary>
        public IActionResult MainView()
        {
            return RedirectToAction("MainView", "Home");
        }

        /// <summary>
        /// Akcja wyświetlająca informacje o anulowaniu rezerwacji.
        /// </summary>
        public IActionResult ReservationDeletedView()
        {
            return View();
        }

        /// <summary>
        /// Akcja wyświetlająca informacje o nie anulowaniu rezerwacji.
        /// </summary>
        public IActionResult ReservationNotDeletedView()
        {
            return View();
        }
    }
}
