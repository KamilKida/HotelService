using HoterlReservation.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using HoterlReservation.Methods;
using HoterlReservation.Connection;
using HoterlReservation.SqlModels;

namespace HoterlReservation.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Akcja kontrolera wy�wietlaj�ca stron� w ktorej NALE�Y okre�li� podstawowe parametry potrzebne do dzia�ania aplikacji.
        /// </summary>
        public IActionResult SetUpView()
        {
            return View();
        }

        /// <summary>
        /// Akcja przypisuj�ca warto�ci parametr�w podstawowych potrzebnych do dzia�ania aplikacji.
        /// </summary>
        /// <param name="email">Email z kt�rego b�d� wysy�ane wiadomo�ci.</param>
        /// <param name="password">Has�o emaila. Generowane dla aplikacji.</param>
        /// <param name="dbServer">Serwer bazy danych.</param>
        /// <param name="dbName">Nazwa bazy danych.</param>
        public IActionResult SetUpInfo(string email, string password, string dbServer, string dbName)
        {
            Params.Email = email;
            Params.Password = password;
            Params.DbServer = dbServer;
            Params.DbName = dbName;

            ConnectionDB.Init();

            return RedirectToAction("MainView", "Home");
        }

        /// <summary>
        /// Akcja anulowania istniej�cej rezerwacji.
        /// </summary>
        /// <param name="clientEmail">E-mail klienta na rezerwacji.</param>
        /// <param name="roomId">Numer pokoju na rezerwacji.</param>
        /// <returns>Czy udalo sie anulowac rezerwacje.</returns>
        public IActionResult ReservationDeleted(string clientEmail, int roomId)
        {
            if(ReservationMethod.DeleteReservation(roomId, clientEmail))
            {
                return RedirectToAction("ReservationDeletedView", "Result");
            }
            else
            {
                return RedirectToAction("ReservationNotDeletedView", "Result");
            }
        }

        /// <summary>
        /// Akcja wy�wietlaj�ca g��wne okno aplikacji.
        /// </summary>
        [HttpGet]
        public IActionResult MainView()
        {

            var listOfRooms = RoomMethods.GetRooms();
           
            return View(listOfRooms);
        }

        /// <summary>
        /// Akcja przekierowuj�ca do wyswietlenia okna do anulowania rezerwacji.
        /// </summary>
        public IActionResult DeleteReservation()
        {
            return RedirectToAction("DeleteRaeservationView", "Home");
        }

        /// <summary>
        /// Akcja wy�wietlaj�ca okna do anulowania rezerwacji.
        /// </summary>
        public IActionResult DeleteRaeservationView()
        {
            return View();
        }
        /// <summary>
        /// Akcja tworz�ca rezerwacje pokoju.
        /// </summary>
        /// <param name="roomId">Numer pokoju.</param>
        /// <param name="clientName">Imie klienta.</param>
        /// <param name="clientSurname">Nazwisko klienta.</param>
        /// <param name="clientEmail">E-mail klienta.</param>
        /// <param name="clientPhoneNumber">Numer telefonu klienta.</param>
        /// <param name="reservedFrom">Zarezerwowane od.</param>
        /// <param name="reservedTo">Zarezerwowane do.</param>
        [HttpPost]
        public IActionResult ReserveRoom(int roomId, string clientName, string clientSurname, string clientEmail, string clientPhoneNumber, DateTime reservedFrom, DateTime reservedTo)
        {
            var listOfRooms = RoomMethods.GetRooms();
            var reservedRoom = listOfRooms.Where(x => x.Id == roomId).FirstOrDefault();

            if (reservedRoom != null)
            {
                if (reservedTo > reservedFrom)
                {
                    if (reservedRoom.IsOccupied == 0)
                    {
                        TimeSpan difference = reservedTo - reservedFrom;

                        int amountOfDays = difference.Days;
                        var client = ClientMethods.GetClient(clientEmail);

                        if (client == null)
                        {
                            client = new Clients()
                            {
                                ClientName = clientName,
                                ClientSurname = clientSurname,
                                Email = clientEmail,
                                PhoneNumber = clientPhoneNumber,
                                AmountOfVisits = 0,
                            };

                            client.Id = ClientMethods.CreateClient(client);
                        }


                        decimal discount = (decimal)(client.AmountOfVisits * 0.05);

                        client.Discount = discount;

                        if (discount > 20)
                        {
                            discount = 20;
                        }

                        decimal reservationPriceNoDiscount = reservedRoom.PriceByDay * amountOfDays;

                        var reservationPrice = reservationPriceNoDiscount * (1 - (discount / 100));

                        var newReservation = new RoomReservations()
                        {
                            ClientId = client.Id,
                            RoomId = roomId,
                            OccupiedFrom = reservedFrom,
                            OccupiedTo = reservedTo,
                            PriceToPay = reservationPrice,
                            OrginalRoomPrice = reservationPriceNoDiscount,
                            Client = client
                        };

                        Params.CreatedReservation = newReservation;
                        ReservationMethod.CreateReservation(newReservation);


                        EmailMethod.SendMail();

                        return RedirectToAction("SuccessWithEmailView", "Result");
                    }


                    else
                    {
                        Params.CreatedReservation.RoomId = roomId;
                        return RedirectToAction("RoomIsOccupiedView", "Result");

                    }
                }
                else
                {
                    Params.CreatedReservation.OccupiedTo = reservedTo;
                    Params.CreatedReservation.OccupiedFrom = reservedFrom;
                    return RedirectToAction("WrongDateView", "Result");
                }
            }
            else
            {
                Params.CreatedReservation.RoomId = roomId;
                return RedirectToAction("WrongRoomView", "Result");
            }
        }
            


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
