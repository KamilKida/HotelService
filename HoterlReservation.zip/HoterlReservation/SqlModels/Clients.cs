﻿namespace HoterlReservation.SqlModels
{
    public class Clients
    {
        public virtual int Id { get; set; }
        public virtual string ClientName { get; set; }
        public virtual string ClientSurname { get; set;}
        public virtual string Email { get; set; }
        public virtual string PhoneNumber { get; set; }
        public virtual int AmountOfVisits { get; set; }
        public virtual decimal Discount { get; set; }
    }
}
