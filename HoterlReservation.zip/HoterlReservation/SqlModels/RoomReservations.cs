﻿namespace HoterlReservation.SqlModels
{
    public class RoomReservations
    {
        public virtual int Id { get; set; }
        public virtual int ClientId { get; set; }
        public virtual int RoomId { get; set; }
        public virtual decimal OrginalRoomPrice { get; set; }
        public virtual decimal PriceToPay { get; set; }
        public virtual DateTime OccupiedFrom { get; set; }
        public virtual DateTime OccupiedTo { get; set; }
        public virtual Clients Client {  get; set; }
    }
}
