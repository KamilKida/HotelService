﻿namespace HoterlReservation.SqlModels
{
    public class Rooms
    {
        public virtual int Id { get; set; }
        public virtual decimal PriceByDay { get; set; }
        public virtual int IsOccupied { get; set; }
        public virtual string IsOccupiedString { get; set; }
    }
}
