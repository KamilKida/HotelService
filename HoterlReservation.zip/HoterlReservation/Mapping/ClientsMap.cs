﻿using HoterlReservation.SqlModels;
using NHibernate.Mapping.ByCode;
using NHibernate.Mapping.ByCode.Conformist;

namespace HoterlReservation.Mapping
{
    public class ClientsMap : ClassMapping<Clients>
    {
        public ClientsMap() 
        {
            Schema("dbo");
            Table("Clients");

            Id(x => x.Id, m => m.Generator(Generators.Identity));

            Property(x => x.ClientName);
            Property(x => x.ClientSurname);
            Property(x => x.Email);
            Property(x => x.PhoneNumber);
            Property(x => x.AmountOfVisits);

            
        }
    }
}
