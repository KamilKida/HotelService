﻿using HoterlReservation.SqlModels;
using NHibernate.Mapping.ByCode;
using NHibernate.Mapping.ByCode.Conformist;

namespace HoterlReservation.Mapping
{
    public class RoomsMap : ClassMapping<Rooms>
    {
        public RoomsMap()
        {
            Schema("dbo");
            Table("Rooms");

            Id(x => x.Id, m => m.Generator(Generators.Identity));

            Property(x => x.PriceByDay);
            Property(x => x.IsOccupied);
        }
    }
}
