﻿using HoterlReservation.SqlModels;
using NHibernate.Mapping.ByCode;
using NHibernate.Mapping.ByCode.Conformist;

namespace HoterlReservation.Mapping
{
    public class RoomReservationsMap : ClassMapping<RoomReservations>
    {
        public RoomReservationsMap()
        {
            Schema("dbo");
            Table("RoomReservations");

            Id(x => x.Id, m => m.Generator(Generators.Identity));

            Property(x => x.ClientId);
            Property(x => x.RoomId);
            Property(x => x.PriceToPay);
            Property(x => x.OccupiedFrom);
            Property(x => x.OccupiedTo);


        }
    }
}
